//
// Created by Anders on 11/08/2022.
//

#ifndef FORNAX3_EVAL_ACTIVITY_INC_H
#define FORNAX3_EVAL_ACTIVITY_INC_H

#include "eval_defs.h"
#include "eval_debug_print.hpp"

static inline eval piece_activity(bits64 attacks, eval activity_value) {
  eval piece_activity = BITS_COUNT(attacks);
  piece_activity += BITS_COUNT(attacks & BB_CENTERMASK16);
  piece_activity *= activity_value;
  return piece_activity;
}

template<bool debug>
static constexpr void eval_activity(eval* mg, eval* eg, const Side* white, const Side* black) {
  eval w_activity = 0;
  eval b_activity = 0;

  bits64 w_pawn_attacks = board_get_pawns_attackmask(white);
  bits64 b_pawn_attacks = board_get_pawns_attackmask(black);
  bits64 w_discounted_squares = b_pawn_attacks | white->piecemask;
  bits64 b_discounted_squares = w_pawn_attacks | black->piecemask;


  for (uint8_t i = 2; i < white->attackmapsize - 1; ++i) {
    Attackmap set = white->attackkmaps[i];
    eval activity_value = ACTIVITYVALUE[set.piece];
    w_activity += piece_activity(set.bits & ~w_discounted_squares, activity_value);
  }
  for (uint8_t i = 2; i < black->attackmapsize - 1; ++i) {
    Attackmap set = black->attackkmaps[i];
    eval activity_value = ACTIVITYVALUE[set.piece];
    b_activity += piece_activity(set.bits & ~b_discounted_squares, activity_value);
  }

  eval activity = ED_ADD_WHITE("activity", w_activity) - ED_ADD_BLACK("activity", b_activity);
  activity = ED_ADD_DIFF("activity", activity / 2);

  *mg += activity;
  *eg += activity;
}

#endif //FORNAX3_EVAL_ACTIVITY_INC_H
