//
//  eval_debug_print.hpp
//  fornax3
//
//  Created by Anders on 25/03/2020.
//

#ifndef eval_debug_print_h
#define eval_debug_print_h

#include "board.h"
#include "eval_defs.h"

#define ED_START(isWhite) if(debug) eval_debug_start(isWhite)
#define ED_ADD_WHITE_MG(topic, val) (debug ? eval_debug_add_white_mg(topic, val) : val)
#define ED_ADD_WHITE_EG(topic, val) (debug ? eval_debug_add_white_eg(topic, val) : val)
#define ED_ADD_WHITE(topic, val) (debug ? eval_debug_add_white(topic, val) : val)
#define ED_ADD_BLACK_MG(topic, val) (debug ? eval_debug_add_black_mg(topic, val) : val)
#define ED_ADD_BLACK_EG(topic, val) (debug ? eval_debug_add_black_eg(topic, val) : val)
#define ED_ADD_BLACK(topic, val) (debug ? eval_debug_add_black(topic, val) : val)
#define ED_ADD_DIFF_EG(topic, val) (debug ? eval_debug_add_diff_eg(topic, val) : val)
#define ED_ADD_DIFF_MG(topic, val) (debug ? eval_debug_add_diff_mg(topic, val) : val)
#define ED_ADD_DIFF(topic, val) (debug ? eval_debug_add_diff(topic, val) : val)
#define ED_END(board, total) if(debug) eval_debug_end(board, total)

void eval_debug_start(bool isWhite);
eval eval_debug_add_white_mg(const char* topic, eval val);
eval eval_debug_add_white_eg(const char* topic, eval val);
eval eval_debug_add_white(const char* topic, eval val);
eval eval_debug_add_black_mg(const char* topic, eval val);
eval eval_debug_add_black_eg(const char* topic, eval val);
eval eval_debug_add_black(const char* topic, eval val);
eval eval_debug_add_diff_mg(const char* topic, eval val);
eval eval_debug_add_diff_eg(const char* topic, eval val);
eval eval_debug_add_diff(const char* topic, eval val);
void eval_debug_end(const Board* board, eval total);
#endif /* eval_debug_print_h */


