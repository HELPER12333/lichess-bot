//
//  eval_endgame_material.inc.h
//  fornax3
//
//  Created by Anders on 10/01/2021.
//

#ifndef eval_endgame_material_inc_h
#define eval_endgame_material_inc_h

#include "../eval_defs.h"

static constexpr eval adjust_for_drawish_endgames(eval material1, eval material2, eval diff) {

  switch (material1) {
    case 0:
      switch (material2) {
        case EVAL_PIECE_BISHOPS:
        case EVAL_PIECE_KNIGHTS:
          return -20;
        case EVAL_PIECE_KNIGHTS * 2:
          return -30;
        case EVAL_PIECE_PAWNS:
          return diff + 25;
      }
      break;
    case EVAL_PIECE_PAWNS:
      switch (material2) {
        case 0:
          return diff - 25;
        case EVAL_PIECE_BISHOPS:
        case EVAL_PIECE_KNIGHTS:
          return 10;
        case EVAL_PIECE_KNIGHTS * 2:
          return -150;
      }
      break;
    case EVAL_PIECE_BISHOPS:
    case EVAL_PIECE_KNIGHTS:
      switch (material2) {
        case 0:
          return 20;
        case EVAL_PIECE_PAWNS:
          return  -10;
        case EVAL_PIECE_BISHOPS * 2:
        case EVAL_PIECE_KNIGHTS * 2:
        case EVAL_PIECE_BISHOPS + EVAL_PIECE_KNIGHTS:
        case EVAL_PIECE_ROOKS:
          return -25;
        case EVAL_PIECE_BISHOPS + EVAL_PIECE_PAWNS:
        case EVAL_PIECE_KNIGHTS + EVAL_PIECE_PAWNS:
          return diff + 50;
      }
      break;
    case EVAL_PIECE_KNIGHTS * 2:
      switch (material2) {
        case 0:
          return  30;
        case EVAL_PIECE_PAWNS:
          return  150;
        case EVAL_PIECE_BISHOPS:
        case EVAL_PIECE_KNIGHTS:
          return 25;
      }
      break;
    case EVAL_PIECE_BISHOPS + EVAL_PIECE_PAWNS:
    case EVAL_PIECE_KNIGHTS + EVAL_PIECE_PAWNS:
      switch (material2) {
        case EVAL_PIECE_BISHOPS:
        case EVAL_PIECE_KNIGHTS:
          return diff - 50;
      }
      break;
    case EVAL_PIECE_KNIGHTS + EVAL_PIECE_BISHOPS:
    case EVAL_PIECE_BISHOPS * 2:
      switch (material2) {
        case EVAL_PIECE_BISHOPS:
        case EVAL_PIECE_KNIGHTS:
          return 25;
      }
      break;
    case EVAL_PIECE_ROOKS:
      switch (material2) {
        case EVAL_PIECE_BISHOPS:
        case EVAL_PIECE_KNIGHTS:
          return 25;
        case EVAL_PIECE_ROOKS + EVAL_PIECE_BISHOPS:
        case EVAL_PIECE_ROOKS + EVAL_PIECE_KNIGHTS:
          return -25;
      }
      break;
    case EVAL_PIECE_ROOKS + EVAL_PIECE_BISHOPS:
    case EVAL_PIECE_ROOKS + EVAL_PIECE_KNIGHTS:
      switch (material2) {
        case EVAL_PIECE_ROOKS:
          return 25;
      }
      break;
  }
  return diff;
}


#endif /* eval_endgame_material_inc_h */
