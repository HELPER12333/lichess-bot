//
//  eval.hpp
//  fornax3
//
//  Created by Anders on 28/12/2020.
//

#ifndef eval_hpp
#define eval_hpp

#include <stdint.h>
#include "board.h"
#include "eval_piecetables.h"

static constexpr eval eval_taper(uint16_t phase, eval mg, eval eg) {
  return (mg * phase + eg * (PHASE_START - phase)) / PHASE_START;
}

eval eval_calculate_contempt(const Board* board);
void eval_set_contempt_factor(long contempt);
eval eval_count_psqt(const Side *side, const piecetable *psqt);
eval eval_count_material(const Side* side);
eval eval_evaluate(const Board* board);
eval eval_evaluate_debug(const Board* board);


#endif /* eval_hpp */
