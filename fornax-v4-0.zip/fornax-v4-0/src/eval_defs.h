//
//  eval_defs.h
//  fornax3
//
//  Created by Anders on 02/01/2021.
//

#ifndef eval_defs_h
#define eval_defs_h

typedef int16_t eval;

constexpr eval EVAL_NONE = INT16_MIN;
constexpr eval EVAL_I_AM_CHECKMATED = -10000;
constexpr eval EVAL_INFINITE = 12345;

constexpr eval EVAL_PIECE_KINGS = 2000;
constexpr eval EVAL_PIECE_PAWNS = 90;
constexpr eval EVAL_PIECE_KNIGHTS = 318;
constexpr eval EVAL_PIECE_BISHOPS = 320;
constexpr eval EVAL_PIECE_ROOKS = 510;
constexpr eval EVAL_PIECE_QUEENS = 950;

constexpr eval EVAL_MATERIAL_VALUE_NULL_THRESHOLD = 500;
constexpr eval EVAL_MATERIAL_VALUE_EXTEND_CHECK_THRESHOLD = 930;

constexpr eval EVAL_MOVEPICK_CAPTURE_BONUS = 500;
constexpr eval EVAL_MOVEPICK_KILLER_VALUE = 400;
constexpr eval EVAL_MOVEPICK_ENPASSANT_VALUE = 600;
constexpr eval EVAL_MOVEPICK_TT_VALUE = 2000;

constexpr eval EVAL_QUIESCE_LIMIT_VALUE = 450;
constexpr eval EVAL_LMR_LIMIT_VALUE = 300;

constexpr eval EVAL_CONTEMPT_DEFAULT = 0;
constexpr eval EVAL_CONTEMPT_MIN = -250;
constexpr eval EVAL_CONTEMPT_MAX = 250;

constexpr eval EVAL_PIECE[6] = {
  EVAL_PIECE_KINGS,
  EVAL_PIECE_QUEENS,
  EVAL_PIECE_ROOKS,
  EVAL_PIECE_BISHOPS,
  EVAL_PIECE_KNIGHTS,
  EVAL_PIECE_PAWNS
};

constexpr uint8_t EVAL_PHASE_QUEENS = 4;
constexpr uint8_t EVAL_PHASE_ROOKS = 2;
constexpr uint8_t EVAL_PHASE_KNIGHTS = 1;
constexpr uint8_t EVAL_PHASE_BISHOPS = 1;

constexpr uint8_t EVAL_PHASE[6] = {
  0,
  EVAL_PHASE_QUEENS,
  EVAL_PHASE_ROOKS,
  EVAL_PHASE_BISHOPS,
  EVAL_PHASE_KNIGHTS,
  0
};

constexpr uint8_t PHASE_START =
EVAL_PHASE_QUEENS * 2
+ EVAL_PHASE_ROOKS * 4
+ EVAL_PHASE_BISHOPS * 4
+ EVAL_PHASE_KNIGHTS * 4;


/* used to adjust piece attack counts*/
constexpr eval EVAL_ACTIVITY_KINGS = 0;
constexpr eval EVAL_ACTIVITY_QUEENS = 2;
constexpr eval EVAL_ACTIVITY_ROOKS = 5;
constexpr eval EVAL_ACTIVITY_KNIGHTS = 7;
constexpr eval EVAL_ACTIVITY_BISHOPS = 7;
constexpr eval EVAL_ACTIVITY_PAWNS = 0;
constexpr eval ACTIVITYVALUE[6] = {
  EVAL_ACTIVITY_KINGS,
  EVAL_ACTIVITY_QUEENS,
  EVAL_ACTIVITY_ROOKS,
  EVAL_ACTIVITY_BISHOPS,
  EVAL_ACTIVITY_KNIGHTS,
  EVAL_ACTIVITY_PAWNS,
};


#endif /* eval_defs_h */
