//
//  oracle.hpp
//  fornax3
//
//  Created by Anders on 04/10/2021.
//

#ifndef oracle_hpp
#define oracle_hpp

#include "../bits.h"

extern bits64* oracle_king_attacks;
extern bits64* oracle_knight_attacks;
extern bits64* oracle_sliding_attacks;
extern bits64* oracle_king_pawn_shield;

static inline bits64 oracle_get_king_attacks(square sq) {
  assert(SQUARE_IS_VALID(sq));
  return oracle_king_attacks[sq];
}

static inline bits64 oracle_get_knight_attacks(square sq) {
  assert(SQUARE_IS_VALID(sq));
  return oracle_knight_attacks[sq];
}

static inline bits64 oracle_get_king_pawn_shield_area(square sq) {
  assert(SQUARE_IS_VALID(sq));
  return oracle_king_pawn_shield[sq];
}

template<direction dir>
static constexpr bits64 oracle_get_slide(square sq) {
  assert(SQUARE_IS_VALID(sq));
  return oracle_sliding_attacks[sq * 8 + dir];
}

void oracle_destroy(void);
void oracle_init(void);

#endif /* oracle_hpp */
