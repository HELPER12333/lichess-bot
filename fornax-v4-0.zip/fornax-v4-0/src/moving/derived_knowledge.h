//
// Created by Anders on 09/08/2022.
//

#ifndef FORNAX3_DERIVED_KNOWLEDGE_H
#define FORNAX3_DERIVED_KNOWLEDGE_H

#include "../board.h"

void derived_knowledge_compute(Board *board);

#endif //FORNAX3_DERIVED_KNOWLEDGE_H
