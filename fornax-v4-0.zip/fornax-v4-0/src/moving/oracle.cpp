//
//  oracle.cpp
//  fornax3
//
//  Created by Anders on 04/10/2021.
//

#include "oracle.hpp"
#include "parsing.hpp"

bits64* oracle_king_attacks;
bits64* oracle_knight_attacks;
bits64* oracle_sliding_attacks;
bits64* oracle_king_pawn_shield;

static void oracle_generate_king_attacks(void) {
  oracle_king_attacks = (bits64*) calloc(64, sizeof(bits64));
  for (int i = 0; i < 64; ++i) {
    bits64 a = BITS_FROM_SQUARE(i);
    oracle_king_attacks[i] =
    a >> 8 | a << 8
    | ((a << 9 | a >> 7 | a << 1 ) & ~BB_FILE_A)
    | ((a >> 9 | a << 7 | a >> 1 ) & ~BB_FILE_H);
  }
}

static void oracle_generate_knight_attacks(void) {
  oracle_knight_attacks = (bits64*) calloc(64, sizeof(bits64));
  for (int i = 0; i < 64; ++i) {
    bits64 a = BITS_FROM_SQUARE(i);
    oracle_knight_attacks[i] =
    ((a << 17 | a >> 15) & ~BB_FILE_A)
    | ((a >> 17 | a << 15) & ~BB_FILE_H)
    | ((a << 10 | a >> 6) & ~(BB_FILE_A | BB_FILE_B))
    | ((a >> 10 | a << 6) & ~(BB_FILE_H | BB_FILE_G));
  }
}

static void oracle_generate_king_pawn_shield_area(void) {
  oracle_king_pawn_shield = (bits64*) calloc(64, sizeof(bits64));
    
  for (int i = 0; i < 16; ++i) {
    bits64 a = BITS_FROM_SQUARE(i);
    oracle_king_pawn_shield[i] = a << 16 | a << 8 | ((a << 9 | a << 1 ) & ~BB_FILE_A) | ((a << 7 | a >> 1 ) & ~BB_FILE_H);
  }
  for (int i = 8; i < 32; ++i) {
    bits64 a = BITS_FROM_SQUARE(i);
    oracle_king_pawn_shield[i] = a << 8 | ((a << 9 | a << 1 ) & ~BB_FILE_A) | ((a << 7 | a >> 1 ) & ~BB_FILE_H);
  }
  for (int i = 32; i < 40; ++i) {
    bits64 a = BITS_FROM_SQUARE(i);
    oracle_king_pawn_shield[i] = a >> 8 | ((a >> 7 | a << 1 ) & ~BB_FILE_A) | ((a >> 9 | a >> 1 ) & ~BB_FILE_H);
  }
  for (int i = 40; i < 64; ++i) {
    bits64 a = BITS_FROM_SQUARE(i);
    oracle_king_pawn_shield[i] = a >> 16 | a >> 8 | ((a >> 7 | a << 1 ) & ~BB_FILE_A) | ((a >> 9 | a >> 1 ) & ~BB_FILE_H);
  }
}

static void oracle_generate_sliding_attacks(void) {
  oracle_sliding_attacks = (bits64*) calloc(64 * 8, sizeof(bits64));
  for (int i = 0; i < 64; ++i) {
    bits64 a = BITS_FROM_SQUARE(i);
    oracle_sliding_attacks[i * 8 + N] = bits_koggestone_occluded_fill<N>(a, BB_MAX) & ~a;
    oracle_sliding_attacks[i * 8 + E] = bits_koggestone_occluded_fill<E>(a, BB_MAX) & ~a;
    oracle_sliding_attacks[i * 8 + S] = bits_koggestone_occluded_fill<S>(a, BB_MAX) & ~a;
    oracle_sliding_attacks[i * 8 + W] = bits_koggestone_occluded_fill<W>(a, BB_MAX) & ~a;
    oracle_sliding_attacks[i * 8 + NE] = bits_koggestone_occluded_fill<NE>(a, BB_MAX) & ~a;
    oracle_sliding_attacks[i * 8 + SE] = bits_koggestone_occluded_fill<SE>(a, BB_MAX) & ~a;
    oracle_sliding_attacks[i * 8 + SW] = bits_koggestone_occluded_fill<SW>(a, BB_MAX) & ~a;
    oracle_sliding_attacks[i * 8 + NW] = bits_koggestone_occluded_fill<NW>(a, BB_MAX) & ~a;
  }
}


void oracle_destroy(void) {
  free(oracle_king_attacks);
  free(oracle_knight_attacks);
  free(oracle_king_pawn_shield);
  free(oracle_sliding_attacks);
}

void oracle_init(void) {
  oracle_generate_king_attacks();
  oracle_generate_knight_attacks();
  oracle_generate_king_pawn_shield_area();
  oracle_generate_sliding_attacks();
}
