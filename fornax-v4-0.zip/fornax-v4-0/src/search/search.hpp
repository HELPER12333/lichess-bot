//
//  search.hpp
//  fornax3
//
//  Created by Anders on 28/04/2019.
//

#ifndef search_h
#define search_h

#include <future>
#include <atomic>
#include "../board.h"
#include "../move.h"
#include "../eval_defs.h"

move search_iterative(const Board* board, uint8_t depth, bool print = true);

std::future<move> search_async_depth(const Board* board, uint8_t depth, bool print = true);
std::future<move> search_async_time(const Board* board, long ms, bool print = true);
std::future<move> search_async_infinite(const Board* board, bool print = true);
void search_async_printinfo(void);
void search_async_stop(void);
bool search_is_searching(void);

#endif /* search_h */
