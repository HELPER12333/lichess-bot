//
//  threads.h
//  project-fornax3
//
//  Created by anders on 25/04/2021.
//

#ifndef threads_h
#define threads_h

static void sleep(long time) {
  std::this_thread::sleep_for(std::chrono::milliseconds(time));
}



#endif /* threads_h */
