//
//  iolog.hpp
//  fornax3
//
//  Created by Anders on 18/03/2020.
//

#ifndef iolog_h
#define iolog_h

#ifdef IO_LOG_ENABLED
#define IO_PRINT iolog_printf
#define IO_GETS iolog_fgets
#define IO_FLUSH iolog_flush
void iolog_printf(const char * c, ...);
char* iolog_fgets(char * c, int size);
void iolog_flush();
#else
#include <stdio.h>
#define IO_PRINT printf
#define IO_GETS(string, size) fgets(string, size, stdin)
#define IO_FLUSH() fflush(stdout);
#endif

#endif /* iolog_h */
