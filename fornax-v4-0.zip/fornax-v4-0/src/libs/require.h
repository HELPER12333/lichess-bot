//
//  require.h
//  fornax3
//
//  Created by Anders on 11/04/2019.
//

#ifndef require_h
#define require_h

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <assert.h>

__attribute__((__format__ (__printf__, 2, 0)))
static inline void require(bool state, const char* message, ...) {
  if (state) return;
  
  va_list arglist;
  va_start( arglist, message );
  vprintf(message, arglist);
  va_end( arglist );
  
  assert(false);
  exit(EXIT_FAILURE);
}


#endif /* require_h */
