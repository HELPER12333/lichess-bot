//
//  iolog.cpp
//  fornax3
//
//  Created by Anders on 18/03/2020.
//

#ifdef IO_LOG_ENABLED
#include "iolog.hpp"
#include <stdarg.h>
#include <stdio.h>

static FILE *logfile;

void iolog_check_init() {
  if (logfile == NULL) {
    logfile = fopen("io.log", "w+");
    fclose(logfile);
    logfile = fopen("io.log", "a+");
  }
}
__attribute__((__format__ (__printf__, 1, 0)))
void iolog_printf(const char * c, ...) {
  iolog_check_init();
  
  va_list args;
  va_start(args, c);
  vprintf(c, args);
  va_end(args);
  
  va_start(args, c);
  vfprintf(logfile, c, args);
  va_end(args);
}

char* iolog_fgets(char * c, int size) {
  iolog_check_init();
  
  char* result = fgets(c, size, stdin);
  if (result == NULL) return NULL;
  
  fputs("> ", logfile);
  fputs(c, logfile);
  fflush(logfile);
  return result;
}

void iolog_flush() {
  iolog_check_init();
  fflush(stdout);
  fflush(logfile);
}

#endif
