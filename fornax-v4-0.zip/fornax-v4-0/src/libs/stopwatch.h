//
//  stopwatch.h
//  fornax3
//
//  Created by Anders on 10/12/2020.
//

#ifndef stopwatch_h
#define stopwatch_h

#include <stdio.h>
#include <thread>
#include <chrono>
#include <functional>

static inline void stopwatch_sleep(long time, std::function<void()> and_then) {
  std::this_thread::sleep_for(std::chrono::milliseconds(time));
  and_then();
}

static inline long stopwatch_wall_start(void) {
  auto now = std::chrono::system_clock::now();
  auto now_ms = std::chrono::time_point_cast<std::chrono::milliseconds>(now);
  auto value = now_ms.time_since_epoch();
  long duration = value.count();
  
  return duration;
}

static inline long stopwatch_wall_stop(long start) {
  return stopwatch_wall_start() - start;
}

static inline void stopwatch_wall_stop_print(long start) {
  printf("time %.3fs\n", (double) stopwatch_wall_stop(start) / 1000);
}

#endif /* stopwatch_h */
