//
//  ints.h
//  fornax3
//
//  Created by Anders on 20/04/2020.
//

#ifndef ints_h
#define ints_h

#define SWAP_INT(x,y) { int swap = x; x = y; y = swap; }
#define MAX_INT(x, y) (((x) > (y)) ? (x) : (y))
#define MIN_INT(x, y) (((x) < (y)) ? (x) : (y))

#endif /* ints_h */
