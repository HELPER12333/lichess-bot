//
//  zobrist.hpp
//  fornax3
//
//  Created by Anders on 26/12/2020.
//

#ifndef zobrist_hpp
#define zobrist_hpp

#include <stdlib.h>
#include <stdint.h>
#include "bits.h"
#include "board.h"

typedef uint64_t ttkey;
extern ttkey* hashes;

void zobrist_init();
void zobrist_destroy();
ttkey zobrist_compute_hash(const Board* b);

template <color color>
static inline ttkey zobrist_get_piece(piecetype piece, square sq) {
  assert(piece != NONE);
  assert(SQUARE_IS_VALID(sq));
  return hashes[color * 6 * 64 + piece * 64 + sq];
}

static inline ttkey zobrist_get_castle(square sq) {
  assert(sq == 0 || sq == 7 || sq == 56 || sq == 63);
  assert(hashes[12 * 64 + sq] != 0);
  return hashes[12 * 64 + sq];
}

static inline ttkey zobrist_get_enpassant(bits64 enpassant) {
  square sq = bits_get_trailing(enpassant);
  assert((sq >= 16 && sq < 24) || (sq >= 40 && sq < 48));
  
  assert(hashes[12 * 64 + sq] != 0);
  return hashes[12 * 64 + sq];
}

static inline ttkey zobrist_get_switchmove(void) {
  assert(hashes[12 * 64 + 49] != 0);
  return hashes[12 * 64 + 49];
}

#endif /* zobrist_hpp */
