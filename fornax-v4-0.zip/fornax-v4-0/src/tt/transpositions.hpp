//
//  transpositions.hpp
//  fornax3
//
//  Created by Anders on 19/06/2019.
//

#ifndef transpositions_h
#define transpositions_h

#include "zobrist.hpp"
#include "../board.h"
#include "../move.h"
#include "../eval_defs.h"

#define TRANSPOSITIONS_SIZE_MB_DEFAULT 128
#define TRANSPOSITIONS_SIZE_PER_MB (64 * 1024)
#define TRANSPOSITIONS_SIZE_MB_MAX (INT32_MAX / (TRANSPOSITIONS_SIZE_PER_MB) - 1)
#define TRANSPOSITIONS_SIZE_MB_MIN 1

typedef uint8_t tttype;
#define TT_TYPE_EXACT 0
#define TT_TYPE_LOWER_BOUND 1
#define TT_TYPE_UPPER_BOUND 2

typedef struct bucket {
  ttkey hash;
  move ttmove;
  eval tteval;
  tttype type;
  uint8_t depth;
  uint8_t age;
} Bucket;

void transpositions_init(void);
void transpositions_clear(void);
void transpositions_destroy(void);
void transpositions_maintenance(void);
void transpositions_status(void);
void transpositions_print(long printLength);
void transpositions_print_bucket(ttkey hash, long offset);
void transpositions_set_hash_size(long MB);

void transpositions_put(ttkey hash, uint8_t depth, eval score, move m, tttype type);
Bucket* transpositions_get(ttkey hash);

#endif /* transpositions_h */
