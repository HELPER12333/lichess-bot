//
//  parsing.hpp
//  fornax3
//
//  Created by Anders on 09/12/2020.
//

#ifndef parsing_hpp
#define parsing_hpp

#include "board.h"
#include "move.h"

#define STARTPOS_FEN "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

move parsing_move_from_uci(const char *ucimove);
move parsing_move_from_san(const Board* b, const char *sanmove);
bool parsing_is_valid_move(const Board* b, move m);
void parsing_to_fen(const Board* b, char* dest);
Board parsing_from_fen(const char* fen);
Board parsing_from_fen_parts(char** parts, int parts_size);

void parsing_printbestmove(move best, move ponder);
void parsing_printcurrmove(move m, uint8_t depth, uint8_t index);
void parsing_printpv(Board* board, move m, uint8_t depth);
void parsing_printmove(move m);
void parsing_printmove_extra(const Board* board, evalmove m);
void parsing_printboard(const Board *b);
void parsing_printfen(const Board *b);
void parsing_printbits_8by8(bits64 bits);
void parsing_printbits_hex(bits64 bits);

#endif /* parsing_hpp */
