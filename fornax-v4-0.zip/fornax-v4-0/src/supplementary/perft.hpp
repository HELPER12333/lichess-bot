//
//  perft.hpp
//  fornax3
//
//  Created by Anders on 18/12/2020.
//

#ifndef perft_hpp
#define perft_hpp

#include "../board.h"

long perft(const Board* board, int depth, bool printmoves);

#endif /* perft_hpp */
