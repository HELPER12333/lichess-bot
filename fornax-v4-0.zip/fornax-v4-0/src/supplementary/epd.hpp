//
//  epd.hpp
//  fornax3
//
//  Created by Anders on 17/10/2021.
//

#ifndef epd_hpp
#define epd_hpp

#include <stdio.h>
#include "../board.h"
#include "../move.h"
#include "../parsing.hpp"

typedef struct {
  Board position;
  move best_move;
} Epd;

void epd_run(int argc, const char * argv[]);
Epd epd_parse(const char* line);

#endif /* epd_hpp */
