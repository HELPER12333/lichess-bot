//
//  time_management.hpp
//  fornax3
//
//  Created by Anders on 05/04/2020.
//

#ifndef time_management_h
#define time_management_h

#include <future>
#include "../board.h"
#include "../tt/transpositions.hpp"

#define TIME_MANAGEMENT_OVERHEAD_DEFAULT 0
#define TIME_MANAGEMENT_OVERHEAD_MAX 50000
#define TIME_MANAGEMENT_OVERHEAD_MIN 0

std::future<move> time_management_parse_uci(const Board* board, char** tokens, int length);
std::future<move> time_management_search(const Board* board, long remainingTime, long increment, long movestogo, bool ponder);
void time_management_ponderhit(const Board* board);

void time_management_send_stopped(void);
bool time_management_check_stop(void);

void time_management_set_overhead(long overhead);
void time_management_set_ponder_enabled(bool enabled);

#endif /* time_management_h */
