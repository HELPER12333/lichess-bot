//
//  opening_book.hpp
//  fornax3
//
//  Created by Anders on 28/03/2020.
//

#ifndef opening_book_h
#define opening_book_h

#include "../board.h"
#include "../move.h"

void opening_book_init(void);
void opening_book_set_enabled(bool is_enabled);
move opening_book_consult(const Board* board);
void opening_book_destroy(void);

#endif /* opening_book_h */
