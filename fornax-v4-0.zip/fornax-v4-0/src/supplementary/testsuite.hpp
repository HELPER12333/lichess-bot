//
//  testsuite.hpp
//  fornax3
//
//  Created by Anders on 18/12/2020.
//

#ifndef testsuite_hpp
#define testsuite_hpp

void testsuite_perft(void);
void testsuite_search(int n);
void testuite_eval(void);

#endif /* testsuite_hpp */
