//
//  epd.cpp
//  fornax3
//
//  Created by Anders on 17/10/2021.
//

#include "epd.hpp"
#include "../libs/strings.h"
#include "../libs/require.h"
#include "../libs/stopwatch.h"
#include "../tt/transpositions.hpp"

#include "../search/search.hpp"

static long success = 0;
static long total = 0;
static long round_success = 0;
static long round_total = 0;
static long ms = 100;
static long rounds = 1;


Epd epd_parse(const char* line) {
  
  char* tokenized[1024];
  char* copy = strings_copy_alloc(line);
  int length = strings_split(copy, tokenized, " ");
  
  int fenEnd = 0;
  for (; fenEnd < length - 1; ++fenEnd) {
    if (string_equals(tokenized[fenEnd], "bm") || fenEnd == 6) {
      break;
    }
  }
  Board p = parsing_from_fen_parts(tokenized, fenEnd);
  
  move bm = parsing_move_from_san(&p, tokenized[fenEnd + 1]);
  free(copy);
  return {p, bm};
}

void epd_run(const char* file) {
  FILE* f = fopen(file, "r");
  require(f != NULL, "file %s not found\n", file);
  char buffer[255];
  
  long file_success = 0;
  long file_total = 0;
  
  while(fgets(buffer, 255, f)) {

    Epd epd = epd_parse(buffer);
    
    move expected = epd.best_move;
    move was = search_async_time(&epd.position, ms, false).get();
    
    transpositions_clear();
    
    if (expected == was) file_success++;
    file_total++;
    
    printf("%d", expected == was ? 1 : 0);
    fflush(stdout);
  }
  fclose(f);
  printf(" = %ld / %ld", file_success, file_total);
  printf("\n");
  round_success += file_success;
  round_total += file_total;
}

void epd_run(const char** files, int count) {
  success = 0;
  total = 0;
  long start = stopwatch_wall_start();
  
  for (long j = 0; j < rounds; ++j) {
    printf("starting round %ld ...\n", j + 1);
    round_success = 0;
    round_total = 0;
    for (int i = 0; i < count; ++i) {
      printf("file %s : ", files[i]);
      epd_run(files[i]);
    }
    success += round_success;
    total += round_total;
    printf("round score %ld / %ld \n", round_success, round_total);
  }
  
  printf("TOTAL EPD TEST %ld / %ld \n", success / rounds, total / rounds);
  stopwatch_wall_stop_print(start);
}

void epd_run(int argc, const char** argv) {
  require(argc > 4, "illegal argument");
  
  ms = string_to_long(argv[2]);
  printf("ms = %ld\n", ms);
  
  rounds = string_to_long(argv[3]);
  printf("rounds = %ld\n", rounds);
  require(rounds > 0, "illegal argument");
  
  epd_run(argv + 4, argc - 4);
}
