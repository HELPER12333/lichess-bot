//
//  move.h
//  fornax3
//
//  Created by Anders on 10/01/2021.
//

#ifndef move_h
#define move_h

#include <future>

typedef uint16_t move;
typedef uint32_t evalmove;
#define MOVE_GET_ORIGIN(mov) (mov & 0x3F)
#define MOVE_GET_DEST(mov) ( mov >> 6 & 0x3F)
#define MOVE_CREATE(origin, dest) ((move) (origin | (dest << 6)))
#define MOVE_GET_PROMOTION(mov) ((piecetype) (mov >> 12 & 0x7))
#define MOVE_ADD_PROMOTION(mov, promotion) ((move) (mov | (promotion << 12)))
#define MOVE_VALUE(evalmove) ((eval) (evalmove >> 16))
constexpr move MOVE_WCQ = 132;
constexpr move MOVE_WCK = 388;
constexpr move MOVE_BCQ = 3772;
constexpr move MOVE_BCK = 4028;

constexpr move MOVE_NONE = 0;

static inline std::future<move> move_now(move m) {
  std::promise<move> p;
  p.set_value(m);
  return p.get_future();
}

static inline std::future<move> move_none() {
  return move_now(MOVE_NONE);
}


#endif /* move_h */
