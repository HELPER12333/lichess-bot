//
//  main.cpp
//  fornax3
//
//  Created by Anders on 13/12/2020.
//

#include <assert.h>
#include <stdio.h>

#include "libs/strings.h"
#include "libs/require.h"
#include "libs/iolog.hpp"
#include "board.h"
#include "supplementary/perft.hpp"
#include "supplementary/testsuite.hpp"
#include "tt/zobrist.hpp"
#include "search/search.hpp"
#include "tt/transpositions.hpp"
#include "supplementary/opening_book.hpp"
#include "uci.hpp"
#include "parsing.hpp"
#include "moving/oracle.hpp"
#include "supplementary/epd.hpp"

static void print_version(void) {
  printf(" ____  ____ _____  __  _   ____  __  __\n");
  printf("| ===|/ () \\| () )|  \\| | / () \\ \\=\\/=/\n");
  printf("|__|  \\____/|_|\\_\\|_|\\__|/__/\\__\\/_/\\_\\\n\n");
  printf("Fornax chess engine by Anders Fuglseth (v");
  uci_printversion();
  printf(")\n");
  fflush(stdout);
  
}

int main(int argc, const char * argv[]) {
  oracle_init();
  zobrist_init();
  transpositions_init();
  opening_book_init();
  uci_init();
  print_version();
  
  if (argc > 1) {
    if (string_equals("-v", argv[1])) {
      return EXIT_SUCCESS;
    }
    else if (string_equals("--epd", argv[1])) {
      epd_run(argc, argv);
      return EXIT_SUCCESS;
    }
  }
  
  char start[32] = "position startpos";
  uci_handlecommand(start);
  
  char *input = (char*) malloc(sizeof(char) * 8192);

  bool next = 1;
  while (next && (IO_GETS(input, 8192)) != NULL) {
    next = uci_handlecommand(input);
  }
  
  free(input);
  
  oracle_destroy();
  uci_destroy();
  opening_book_destroy();
  transpositions_destroy();
  zobrist_destroy();
  
  return EXIT_SUCCESS;
}
