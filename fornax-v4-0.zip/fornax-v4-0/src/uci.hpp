//
//  uci.hpp
//  fornax3
//
//  Created by Anders on 24/04/2019.
//

#ifndef uci_h
#define uci_h

#include <stdbool.h>

void uci_init(void);
void uci_destroy(void);
bool uci_handlecommand(char* command);
void uci_printversion(void);

#endif /* uci_h */
