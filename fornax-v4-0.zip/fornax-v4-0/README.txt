Fornax chess engine v4.0
by Anders

COMPILATION

Use 'make' to compile from source.

Fornax 4 is written in C++.
For Windows systems I encountered a problem that certain MinGW Windows compilers are missing a
std::future implementation.

LICENSE

Binaries may be used and redistributed freely.
